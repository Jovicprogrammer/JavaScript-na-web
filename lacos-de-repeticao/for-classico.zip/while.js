// let i = 0

//     while (i <= 10) {

//         alert(`A variavel i é ${i}`)
//         i++
//     }

let i = 1;
    do {
        alert(`A variavel i é ${i}`)
        i++
    } while (i <= 10)
        