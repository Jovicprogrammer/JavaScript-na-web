// const frutas = ["laranja", "maracujá", "limão"];

// for (let fruta of frutas) {
//     alert(fruta)
// }

const notas = [10, 5, 6, 7, 8]

let somaTotal = 0

for (let nota of notas) {
    // somaTotal = somaTotal + nota
    somaTotal += nota
}
